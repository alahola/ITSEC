'''
@author: Christian Wressnegger
'''

RSA = [
    {'e': 211, 'n': 67063, 'ciphertext': 19307, 'msg': 20459}
]

DH = [
    {'g': 10, 'n': 1783, 'alice': 929, 'bob': 626, 'key': 435}
]
